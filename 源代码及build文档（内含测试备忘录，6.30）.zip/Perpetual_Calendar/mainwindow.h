#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QActionGroup>

#include <QWidget>
#include <QCalendarWidget>

#include <QGridLayout>
#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QGroupBox>

#include <QLabel>
#include <QLineEdit>
#include <QDateEdit>
#include <QTextEdit>
#include <vector>
#include <algorithm>

#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonParseError>
#include <QFile>

#include <QTextDocument>
#include <QTextCursor>
#include <QTextFrame>
#include <QTextFrameFormat>

#include <QString>
#include <QRandomGenerator>
#include <Qtimer>
#include <QDateTime>
#include <QSpinBox>
#include <QPushButton>

#include <QStackedWidget>
#include <QTextEdit>
#include <Qdir>
#include <QDebug>

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // Date Selector日期选择
    void selectedDateChanged();

    // Menu主界面
    void setWERed();
    void setWEBlu();
    void setWEBlk();
    void setWEClr(QColor col);

    void setWDRed();
    void setWDBlu();
    void setWDBlk();
    void setWDClr(QColor col);

    void toggleGridMode();

    void prevPage();
    void nextPage();//翻页
    void saveMemo();
    void clearMemo();//备忘
    void loadMemoForDate();

private:

    // Menu
    void createMenu();
    QMenuBar *menubar;
    QMenu *settingsMenu;
    QWidget* createPage1();
    QWidget* createPage2();//为了翻页

    // Calendar
    void createCalendar();
    QCalendarWidget *calendar;
    QGridLayout *layout;
    QVBoxLayout *sidebar;


    // Date Selector
    void createDateSelector();

    QGroupBox *dateSelect_box;
    QDateEdit *dateSelect;
    QLabel *dateSelect_label;

    //农历日期
    void createNL();
    void NL();
    QGroupBox *NL_box;
    QLabel *NL_label;
    QLineEdit *NL_data;

    //系统时间
    QLabel *timeLabel;
    QTimer *timer;
    QGroupBox *timeDisplay_box;
    void updateTimeDisplay();
    void createTimeDisplay();

    //日期计算相关函数
    void createDateCalculator();//日期计算功能
    void calculateDateDifference(); // 计算日期差
    void jumpToDate();//跳转指定天数日期
    QGroupBox *dateCalc_box;
    QDateEdit *startDateEdit;
    QDateEdit *endDateEdit;
    QLabel *intervalResultLabel;
    QSpinBox *daysInput;
    QLabel *jumpResultLabel;

    // 翻页相关
    QStackedWidget *stackedWidget;
    QPushButton *prevPageButton;
    QPushButton *nextPageButton;

    //备忘录
    void createMemoPage();
    QDateEdit *memoDateEdit;
    QTextEdit *memoEdit;
    QLabel *memoStatus;
    QLabel *memoTitle;
    QString memoDir;
    QDate currentMemoDate;


    //字体函数
    QFont getAppFont();

public:
    void setNL(QString n)
    {
        nlrq = n;
    }
    QString getNL() const { return nlrq; };
private:
    QString nlrq;

};
#endif // MAINWINDOW_H
