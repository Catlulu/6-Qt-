#include "mainwindow.h"
#include <iostream>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    const int width(1280);
    const int height(720);//主界面大小，宽高
    setWindowTitle(tr("PerpetualCalendar"));
    setFixedSize(width, height);//固定窗口大小

    // Calling Creates
    createMenu();
    createCalendar();
    createDateSelector();//日期选择
    createNL();//农历日期
    createTimeDisplay();//当前时间
    createDateCalculator();//计算日期以及多少天跳转

    // 初始化备忘录目录
    memoDir = QDir::currentPath() + "/CalendarMemos";//备忘录路径，是在当前项目的build文件下
    QDir dir;
    if (!dir.exists(memoDir)) {
        dir.mkpath(memoDir);
    }

    //创建侧边栏
    QWidget *cebian = new QWidget();
    sidebar = new QVBoxLayout;

    //创建翻页按钮
    QHBoxLayout *pageButtonsLayout = new QHBoxLayout;
    prevPageButton = new QPushButton("上一页");
    prevPageButton->setFont(getAppFont());
    nextPageButton = new QPushButton("下一页");
    nextPageButton->setFont(getAppFont());
    pageButtonsLayout->addWidget(prevPageButton);
    pageButtonsLayout->addWidget(nextPageButton);//上下页按钮以及字体设置

    //创建堆栈窗口用于翻页
    stackedWidget = new QStackedWidget;
    stackedWidget->addWidget(createPage1()); // 第一页
    stackedWidget->addWidget(createPage2()); // 第二页（备忘录）

    //将翻页按钮和堆栈窗口添加到侧边栏布局
    sidebar->addLayout(pageButtonsLayout);
    sidebar->addWidget(stackedWidget);

    //侧边栏布局
    cebian->setLayout(sidebar);
    cebian->setFixedWidth(width * 0.25);
    cebian->setFixedHeight(height - menubar->height());

    //创建主布局（网格布局）
    layout = new QGridLayout;
    layout->addWidget(calendar, 0, 0);
    layout->addWidget(cebian, 0, 1);

    layout->setRowMinimumHeight(0, height - menubar->height());
    layout->setColumnMinimumWidth(0, calendar->width());
    layout->setSizeConstraint(QLayout::SetFixedSize);

    //设置中央部件
    QWidget *central = new QWidget(this);
    central->setLayout(layout);
    setCentralWidget(central);

    //设置边距
    centralWidget()->layout()->setContentsMargins(5, 5, 5, 5);

    //连接翻页按钮信号到槽函数
    connect(prevPageButton, &QPushButton::clicked, this, &MainWindow::prevPage);
    connect(nextPageButton, &QPushButton::clicked, this, &MainWindow::nextPage);
}

//字体设置函数 我使用的楷体
QFont MainWindow::getAppFont()
{
    QFont font;

    // 尝试使用楷体，如果系统没有楷体则使用默认字体
    if (QFontDatabase::families().contains("楷体")) {
        font.setFamily("楷体");
    } else if (QFontDatabase::families().contains("KaiTi")) {
        font.setFamily("KaiTi");
    }else{
        font.setFamily("Microsoft YaHei");
    }

    font.setPointSize(12);//字体大小为12
    return font;
}

//左上角菜单栏
void MainWindow::createMenu()
{
    menubar = menuBar();

    QFont menuFont = menubar->font();
    menubar->setFont(getAppFont());

    settingsMenu = menubar->addMenu(tr("&设置"));
    settingsMenu->setFont(menuFont);

    // Weekday Color
    QMenu* weekday_col = settingsMenu->addMenu(tr("Weekday Color"));
    QActionGroup* wdc = new QActionGroup(weekday_col);
    QAction *wdc_red = wdc->addAction(tr("Red"));
    weekday_col->addAction(wdc_red);
    QAction *wdc_blk = wdc->addAction(tr("Black"));
    weekday_col->addAction(wdc_blk);
    QAction *wdc_blu = wdc->addAction(tr("Blue"));
    weekday_col->addAction(wdc_blu);

    for (auto* a : wdc->actions())
        a->setCheckable(true);

    wdc->setExclusionPolicy(QActionGroup::ExclusionPolicy::Exclusive);
    wdc_blk->setChecked(true);

    connect(wdc_red, &QAction::triggered,
            this, &MainWindow::setWDRed);
    connect(wdc_blu, &QAction::triggered,
            this, &MainWindow::setWDBlu);
    connect(wdc_blk, &QAction::triggered,
            this, &MainWindow::setWDBlk);

    // Weekend Color
    QMenu* weekend_col = settingsMenu->addMenu(tr("Weekend Color"));
    QActionGroup* wec = new QActionGroup(weekend_col);
    QAction *wec_red = wec->addAction(tr("Red"));
    weekend_col->addAction(wec_red);
    QAction *wec_blk = wec->addAction(tr("Black"));
    weekend_col->addAction(wec_blk);
    QAction *wec_blu = wec->addAction(tr("Blue"));
    weekend_col->addAction(wec_blu);

    for (auto* a : wec->actions())
        a->setCheckable(true);

    wec->setExclusionPolicy(QActionGroup::ExclusionPolicy::Exclusive);
    wec_red->setChecked(true);

    connect(wec_red, &QAction::triggered,
            this, &MainWindow::setWERed);
    connect(wec_blu, &QAction::triggered,
            this, &MainWindow::setWEBlu);
    connect(wec_blk, &QAction::triggered,
            this, &MainWindow::setWEBlk);


    // Grid Mode
    QAction* gridMode = settingsMenu->addAction(tr("Toggle Grid Mode"));//是否显示网格线

    connect(gridMode, &QAction::triggered,
            this, &MainWindow::toggleGridMode);
}

//切换网格显示
void MainWindow::toggleGridMode()
{
    calendar->setGridVisible(!calendar->isGridVisible());
}
void MainWindow::setWERed()
{
    setWEClr(QColor(Qt::red));
}
void MainWindow::setWEBlu()
{
    setWEClr(QColor(Qt::blue));
}
void MainWindow::setWEBlk()
{
    setWEClr(QColor(Qt::black));
}
void MainWindow::setWEClr(QColor col)
{
    QTextCharFormat format;

    format.setForeground(qvariant_cast<QColor>(col));
    calendar->setWeekdayTextFormat(Qt::Saturday, format);
    calendar->setWeekdayTextFormat(Qt::Sunday, format);
}
void MainWindow::setWDRed()
{
    setWDClr(QColor(Qt::red));
}
void MainWindow::setWDBlu()
{
    setWDClr(QColor(Qt::blue));
}
void MainWindow::setWDBlk()
{
    setWDClr(QColor(Qt::black));
}
void MainWindow::setWDClr(QColor col)
{
    QTextCharFormat format;

    format.setForeground(qvariant_cast<QColor>(col));
    calendar->setWeekdayTextFormat(Qt::Monday, format);
    calendar->setWeekdayTextFormat(Qt::Tuesday, format);
    calendar->setWeekdayTextFormat(Qt::Wednesday, format);
    calendar->setWeekdayTextFormat(Qt::Thursday, format);
    calendar->setWeekdayTextFormat(Qt::Friday, format);
}

//创建日历组件
void MainWindow::createCalendar()
{
    // Calendar
    calendar = new QCalendarWidget;
    calendar->setFont(getAppFont());

    calendar->resize(width() * 0.75, height());
    calendar->setGridVisible(true);

    calendar->setDateEditEnabled(false);

}

//页面创建函数
QWidget* MainWindow::createPage1()
{
    QWidget *page = new QWidget;
    QVBoxLayout *pageLayout = new QVBoxLayout;

    // 添加已创建的功能组件到页面
    pageLayout->addWidget(timeDisplay_box);
    pageLayout->addWidget(dateSelect_box);
    pageLayout->addWidget(NL_box);
    pageLayout->addWidget(dateCalc_box);

    page->setLayout(pageLayout);
    return page;
}
QWidget* MainWindow::createPage2()
{
    QWidget *page = new QWidget;
    QVBoxLayout *pageLayout = new QVBoxLayout;

    // 备忘录标题
    memoTitle = new QLabel(tr("备忘录"));
    memoTitle->setFont(getAppFont());
    memoTitle->setAlignment(Qt::AlignCenter);

    // 日期选择器
    QHBoxLayout *dateLayout = new QHBoxLayout;
    dateLayout->addWidget(new QLabel(tr("日期:")));
    memoDateEdit = new QDateEdit(calendar->selectedDate());
    memoDateEdit->setFont(getAppFont());
    memoDateEdit->setDisplayFormat("yyyy-MM-dd");

    QPushButton *refreshButton = new QPushButton(tr("刷新"));
    refreshButton->setFont(getAppFont());

    dateLayout->addWidget(memoDateEdit);
    dateLayout->addWidget(refreshButton);

    // 文本编辑框
    memoEdit = new QTextEdit;
    memoEdit->setFont(getAppFont());
    memoEdit->setPlaceholderText(tr("在此输入您的备忘内容..."));

    // 按钮布局
    QHBoxLayout *buttonLayout = new QHBoxLayout;
    QPushButton *saveButton = new QPushButton(tr("保存备忘"));
    saveButton->setFont(getAppFont());
    QPushButton *clearButton = new QPushButton(tr("清空内容"));
    clearButton->setFont(getAppFont());

    buttonLayout->addWidget(saveButton);
    buttonLayout->addWidget(clearButton);

    // 状态标签
    memoStatus = new QLabel;
    memoStatus->setFont(getAppFont());
    memoStatus->setAlignment(Qt::AlignCenter);

    // 添加所有组件到布局
    pageLayout->addWidget(memoTitle);
    pageLayout->addLayout(dateLayout);
    pageLayout->addWidget(memoEdit, 1);
    pageLayout->addLayout(buttonLayout);
    pageLayout->addWidget(memoStatus);

    page->setLayout(pageLayout);

    // 连接信号
    connect(saveButton, &QPushButton::clicked, this, &MainWindow::saveMemo);
    connect(clearButton, &QPushButton::clicked, this, &MainWindow::clearMemo);
    connect(refreshButton, &QPushButton::clicked, this, [this]() {
        // 获取备忘录日期选择器的日期
        QDate selectedDate = memoDateEdit->date();
        // 更新日历的选中日期
        calendar->setSelectedDate(selectedDate);
        // 加载该日期的备忘录
        loadMemoForDate();
    });
    connect(memoDateEdit, &QDateEdit::dateChanged, this, &MainWindow::loadMemoForDate);

    // 加载当前日期的备忘录
    loadMemoForDate();

    return page;
}

//上一页按钮槽函数
void MainWindow::prevPage()
{
    int current = stackedWidget->currentIndex();
    if (current > 0) {
        stackedWidget->setCurrentIndex(current - 1);
    }
}
//下一页
void MainWindow::nextPage()
{
    int current = stackedWidget->currentIndex();
    if (current < stackedWidget->count() - 1) {
        stackedWidget->setCurrentIndex(current + 1);
    }
}

//日期选择器
void MainWindow::createDateSelector()
{
    // Date Selector
    dateSelect_box = new QGroupBox(tr("指定日期跳转"));
    dateSelect_box->setFont(getAppFont());

    dateSelect = new QDateEdit(calendar->selectedDate());
    dateSelect->setFont(getAppFont());
    dateSelect->setDateRange(
                calendar->minimumDate(),
                calendar->maximumDate());
    dateSelect->setDisplayFormat("yyyy MMM dd");


    dateSelect_label = new QLabel(tr("指定日期"));
    dateSelect_label->setFont(getAppFont());
    dateSelect_label->setBuddy(dateSelect);

    QGridLayout *dateSelect_layout = new QGridLayout;
    dateSelect_layout->addWidget(dateSelect_label, 0, 0);
    dateSelect_layout->addWidget(dateSelect, 0, 1);
    dateSelect_layout->setSizeConstraint(QLayout::SetMinimumSize);


    dateSelect_box->setLayout(dateSelect_layout);
    dateSelect_box->setFixedHeight(40);


    // 连接日期变更信号
    connect(dateSelect, &QDateEdit::dateChanged,
            calendar, &QCalendarWidget::setSelectedDate);
    connect(calendar, &QCalendarWidget::selectionChanged,
            this, &MainWindow::selectedDateChanged);
}

//选择日期变化的槽函数
void MainWindow::selectedDateChanged()
{
    QDate current = calendar->selectedDate();
    dateSelect->setDate(current);
    jumpResultLabel->setText(tr("目标日期: %1").arg(current.toString("yyyy-MM-dd")));

    // 如果当前在备忘录页面，更新日期并加载备忘录
    if (stackedWidget && stackedWidget->currentIndex() == 1) {
        memoDateEdit->setDate(current);
        loadMemoForDate();
    }
}

//农历日期组件
void MainWindow::createNL()
{
    NL_box = new QGroupBox(tr("农历"));
    NL_box->setFont(getAppFont());

    QFont font = getAppFont();

    NL_label = new QLabel(tr("显示农历日期"));
    NL_label->setFont(font);
    NL_data = new QLineEdit;
    NL_data->setFont(font);
    NL_data->setReadOnly(true);
    NL_data->setText("农历日期");
    NL();
    connect(calendar,&QCalendarWidget::selectionChanged,this,&MainWindow::NL);
    connect(dateSelect, &QDateEdit::dateChanged,this,&MainWindow::NL);

    QHBoxLayout *nl_layout = new QHBoxLayout;
    nl_layout->addWidget(NL_label);
    nl_layout->addWidget(NL_data);
    nl_layout->setSizeConstraint(QLayout::SetMinimumSize);

    NL_box->setLayout(nl_layout);
    NL_box->setFixedHeight(40);
}

//使用json文件保存每年每日农历数据
void MainWindow::NL(){
    QString path=":/new/prefix1/json_nl/";
    path+=QString::number(calendar->selectedDate().year());
    path+=".json";
    QFile file(path);
    if(!file.open(QFile::ReadOnly)){
       setNL("error");
    }

    QByteArray byteArr = file.readAll();
    QJsonParseError err;
    QJsonDocument Doc= QJsonDocument::fromJson(byteArr,&err);
    QString str;
    QJsonArray arr = Doc.array();
    for(int i=0;i<arr.count();i++){
        QJsonValue datevalue=arr.at(i);
        if(datevalue.type()==QJsonValue::Object){
            QJsonObject dateobj=datevalue.toObject();
            QJsonValue date_gl_val=dateobj.value("gregorian");
            if(date_gl_val.type()==QJsonValue::Object){
                QJsonObject date_gl_obj = date_gl_val.toObject();
                int month_from_json = date_gl_obj.value("month").toInt();
                int day_from_json = date_gl_obj.value("date").toInt();
                if(month_from_json==calendar->selectedDate().month()&&day_from_json==calendar->selectedDate().day()){
                    QJsonValue date_nl_val=dateobj.value("lunar");
                    if(date_nl_val.type()==QJsonValue::Object){
                        QJsonObject date_nl_obj=date_nl_val.toObject();
                        str+=date_nl_obj.value("year").toString();
                        str+=date_nl_obj.value("month").toString();
                        str+=date_nl_obj.value("date").toString();
                    }
                }
            }
        }
    }

    setNL(str);
    NL_data->setText(nlrq);
}

//当前时间组件
void MainWindow::createTimeDisplay()
{
    timeDisplay_box = new QGroupBox(tr("当前时间"));
    timeDisplay_box->setFont(getAppFont());

    timeLabel = new QLabel();
    timeLabel->setFont(getAppFont());
    timeLabel->setAlignment(Qt::AlignCenter);
    updateTimeDisplay();
    QTimer *timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &MainWindow::updateTimeDisplay);
    timer->start(1000);

    QVBoxLayout *timeLayout = new QVBoxLayout;
    timeLayout->addWidget(timeLabel);
    timeDisplay_box->setLayout(timeLayout);
    timeDisplay_box->setFixedHeight(80);
}

//更新时间
void MainWindow::updateTimeDisplay()
{
    QString currentTime = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
    timeLabel->setText(currentTime);

    timeLabel->setFont(getAppFont());
}

//创建日期计算功能组件
void MainWindow::createDateCalculator()
{
    QFont font = getAppFont();  // 获取统一字体
    //计算日期间隔
    QGroupBox *intervalGroup = new QGroupBox(tr("计算日期间隔"));
    intervalGroup->setFont(font);

    QVBoxLayout *intervalLayout = new QVBoxLayout;

    QLabel *startDateLabel = new QLabel(tr("开始日期:"));
    startDateEdit = new QDateEdit(calendar->selectedDate());
    startDateEdit->setDisplayFormat("yyyy-MM-dd");

    QLabel *endDateLabel = new QLabel(tr("结束日期:"));
    endDateEdit = new QDateEdit(calendar->selectedDate());
    endDateEdit->setDisplayFormat("yyyy-MM-dd");

    QPushButton *calcButton = new QPushButton(tr("计算间隔天数"));
    intervalResultLabel = new QLabel(tr("间隔: 0 天"));

    intervalLayout->addWidget(startDateLabel);
    intervalLayout->addWidget(startDateEdit);
    intervalLayout->addWidget(endDateLabel);
    intervalLayout->addWidget(endDateEdit);
    intervalLayout->addWidget(calcButton);
    intervalLayout->addWidget(intervalResultLabel);

    intervalGroup->setLayout(intervalLayout);

    //指定时间前后跳转
    QGroupBox *jumpGroup = new QGroupBox(tr("日期跳转"));
    QGridLayout *jumpLayout = new QGridLayout;

    QLabel *jumpLabel = new QLabel(tr("跳转天数:"));
    daysInput = new QSpinBox();
    daysInput->setRange(-3650, 3650); // ±10年范围
    daysInput->setValue(0);

    QPushButton *pastButton = new QPushButton(tr("跳转到之前"));
    QPushButton *futureButton = new QPushButton(tr("跳转到之后"));
    jumpResultLabel = new QLabel(tr("目标日期:"));

    jumpLayout->addWidget(jumpLabel, 0, 0);
    jumpLayout->addWidget(daysInput, 0, 1);
    jumpLayout->addWidget(pastButton, 1, 0);
    jumpLayout->addWidget(futureButton, 1, 1);
    jumpLayout->addWidget(jumpResultLabel, 2, 0, 1, 2);

    jumpGroup->setLayout(jumpLayout);

    //两个组件整体布局
    dateCalc_box = new QGroupBox(tr("日期计算工具"));
    dateCalc_box->setFont(font);
    QVBoxLayout *mainCalcLayout = new QVBoxLayout;
    mainCalcLayout->addWidget(intervalGroup);
    mainCalcLayout->addWidget(jumpGroup);
    dateCalc_box->setLayout(mainCalcLayout);

    //信号槽函数
    connect(calcButton, &QPushButton::clicked,
            this, &MainWindow::calculateDateDifference);
    connect(pastButton, &QPushButton::clicked,
            this, &MainWindow::jumpToDate);
    connect(futureButton, &QPushButton::clicked,
            this, &MainWindow::jumpToDate);
}

//使用自带函数计算日期差
void MainWindow::calculateDateDifference()
{
    QDate start = startDateEdit->date();
    QDate end = endDateEdit->date();

    if (start > end) {
        std::swap(start, end);
        startDateEdit->setDate(start);
        endDateEdit->setDate(end);
    }

    qint64 days = start.daysTo(end);
    intervalResultLabel->setText(tr("间隔: %1 天").arg(days));
}

//日期跳转功能
void MainWindow::jumpToDate()
{
    QPushButton *button = qobject_cast<QPushButton*>(sender());
    if (!button) return;

    bool toPast = (button->text() == tr("跳转到之前"));
    int days = daysInput->value();
    if (!toPast && days < 0) days = -days; // 确保方向正确

    QDate current = calendar->selectedDate();
    QDate newDate;

    if (toPast) {
        newDate = current.addDays(-days);
    } else {
        newDate = current.addDays(days);
    }

    // 更新日历显示
    calendar->setSelectedDate(newDate);
    jumpResultLabel->setText(tr("目标日期: %1").arg(newDate.toString("yyyy-MM-dd")));

    // 同时更新顶部的日期选择器
    dateSelect->setDate(newDate);
}

//保存备忘录
void MainWindow::saveMemo()
{
    QString memoText = memoEdit->toPlainText();
    if (memoText.isEmpty()) {
        memoStatus->setText(tr("备忘内容不能为空！"));
        QTimer::singleShot(3000, this, [this]() { memoStatus->clear(); });
        return;
    }

    QDate currentDate = memoDateEdit->date();
    QString fileName = memoDir + "/" + currentDate.toString("yyyyMMdd") + ".txt";
    QFile file(fileName);

    if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream out(&file);
        out << memoText;
        file.close();
        memoStatus->setText(tr("%1 的备忘保存成功！").arg(currentDate.toString("yyyy-MM-dd")));

        QTimer::singleShot(3000, this, [this]() { memoStatus->clear(); });
    } else {
        memoStatus->setText(tr("保存失败，无法写入文件！"));
        QTimer::singleShot(3000, this, [this]() { memoStatus->clear(); });
    }
}

//清空备忘录内容
void MainWindow::clearMemo()
{
    memoEdit->clear();
    memoStatus->setText(tr("内容已清空"));
    QTimer::singleShot(2000, this, [this]() { memoStatus->clear(); });
}

//加载指定日期的备忘录
void MainWindow::loadMemoForDate()
{
    QDate dateToLoad = memoDateEdit->date();
    QString fileName = memoDir + "/" + dateToLoad.toString("yyyyMMdd") + ".txt";
    QFile file(fileName);

    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        memoEdit->setText(in.readAll());
        file.close();
        memoStatus->setText(tr("已加载 %1 的备忘录").arg(dateToLoad.toString("yyyy-MM-dd")));
    } else {
        memoEdit->clear();
        memoStatus->setText(tr("没有找到 %1 的备忘录").arg(dateToLoad.toString("yyyy-MM-dd")));
    }

    QTimer::singleShot(3000, this, [this]() { memoStatus->clear(); });
}

MainWindow::~MainWindow()
{
    //Menu
    delete menubar;
    delete settingsMenu;

    //Date Selector
    delete dateSelect_box;
    delete dateSelect;
    delete dateSelect_label;

    //NL
    delete NL_box;
    delete NL_label;
    delete NL_data;

    //time
    delete timeDisplay_box;
    delete timeLabel;

    //Calendar
    delete calendar;
    delete layout;
    delete sidebar;

    //page
    delete stackedWidget;
    delete prevPageButton;
    delete nextPageButton;

    //memo
    delete memoDateEdit;
    delete memoEdit;
    delete memoStatus;
    delete memoTitle;
}

