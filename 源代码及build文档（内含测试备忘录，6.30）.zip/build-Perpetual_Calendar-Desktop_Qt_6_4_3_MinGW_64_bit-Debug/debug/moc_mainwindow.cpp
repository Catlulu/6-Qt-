/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../Perpetual_Calendar/mainwindow.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_MainWindow_t {
    uint offsetsAndSizes[36];
    char stringdata0[11];
    char stringdata1[20];
    char stringdata2[1];
    char stringdata3[9];
    char stringdata4[9];
    char stringdata5[9];
    char stringdata6[9];
    char stringdata7[4];
    char stringdata8[9];
    char stringdata9[9];
    char stringdata10[9];
    char stringdata11[9];
    char stringdata12[15];
    char stringdata13[9];
    char stringdata14[9];
    char stringdata15[9];
    char stringdata16[10];
    char stringdata17[16];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_MainWindow_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 19),  // "selectedDateChanged"
        QT_MOC_LITERAL(31, 0),  // ""
        QT_MOC_LITERAL(32, 8),  // "setWERed"
        QT_MOC_LITERAL(41, 8),  // "setWEBlu"
        QT_MOC_LITERAL(50, 8),  // "setWEBlk"
        QT_MOC_LITERAL(59, 8),  // "setWEClr"
        QT_MOC_LITERAL(68, 3),  // "col"
        QT_MOC_LITERAL(72, 8),  // "setWDRed"
        QT_MOC_LITERAL(81, 8),  // "setWDBlu"
        QT_MOC_LITERAL(90, 8),  // "setWDBlk"
        QT_MOC_LITERAL(99, 8),  // "setWDClr"
        QT_MOC_LITERAL(108, 14),  // "toggleGridMode"
        QT_MOC_LITERAL(123, 8),  // "prevPage"
        QT_MOC_LITERAL(132, 8),  // "nextPage"
        QT_MOC_LITERAL(141, 8),  // "saveMemo"
        QT_MOC_LITERAL(150, 9),  // "clearMemo"
        QT_MOC_LITERAL(160, 15)   // "loadMemoForDate"
    },
    "MainWindow",
    "selectedDateChanged",
    "",
    "setWERed",
    "setWEBlu",
    "setWEBlk",
    "setWEClr",
    "col",
    "setWDRed",
    "setWDBlu",
    "setWDBlk",
    "setWDClr",
    "toggleGridMode",
    "prevPage",
    "nextPage",
    "saveMemo",
    "clearMemo",
    "loadMemoForDate"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_MainWindow[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  104,    2, 0x08,    1 /* Private */,
       3,    0,  105,    2, 0x08,    2 /* Private */,
       4,    0,  106,    2, 0x08,    3 /* Private */,
       5,    0,  107,    2, 0x08,    4 /* Private */,
       6,    1,  108,    2, 0x08,    5 /* Private */,
       8,    0,  111,    2, 0x08,    7 /* Private */,
       9,    0,  112,    2, 0x08,    8 /* Private */,
      10,    0,  113,    2, 0x08,    9 /* Private */,
      11,    1,  114,    2, 0x08,   10 /* Private */,
      12,    0,  117,    2, 0x08,   12 /* Private */,
      13,    0,  118,    2, 0x08,   13 /* Private */,
      14,    0,  119,    2, 0x08,   14 /* Private */,
      15,    0,  120,    2, 0x08,   15 /* Private */,
      16,    0,  121,    2, 0x08,   16 /* Private */,
      17,    0,  122,    2, 0x08,   17 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QColor,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QColor,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.offsetsAndSizes,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_MainWindow_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'selectedDateChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setWERed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setWEBlu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setWEBlk'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setWEClr'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QColor, std::false_type>,
        // method 'setWDRed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setWDBlu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setWDBlk'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setWDClr'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QColor, std::false_type>,
        // method 'toggleGridMode'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'prevPage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'nextPage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'saveMemo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'clearMemo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'loadMemoForDate'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->selectedDateChanged(); break;
        case 1: _t->setWERed(); break;
        case 2: _t->setWEBlu(); break;
        case 3: _t->setWEBlk(); break;
        case 4: _t->setWEClr((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        case 5: _t->setWDRed(); break;
        case 6: _t->setWDBlu(); break;
        case 7: _t->setWDBlk(); break;
        case 8: _t->setWDClr((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        case 9: _t->toggleGridMode(); break;
        case 10: _t->prevPage(); break;
        case 11: _t->nextPage(); break;
        case 12: _t->saveMemo(); break;
        case 13: _t->clearMemo(); break;
        case 14: _t->loadMemoForDate(); break;
        default: ;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 15;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
